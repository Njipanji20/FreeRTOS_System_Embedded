/**
 * ============================================================
 *  STM32F103C8T6 - FreeRTOS Demo
 *  Task 1 : LED Blink (toggle setiap 1 detik)
 *  Task 2 : Baca suhu & kelembaban DHT22
 *
 *  Wiring:
 *    LED    -> PC13 (onboard LED, active LOW)
 *    DHT22  -> Data pin -> PA1
 *               VCC     -> 3.3V / 5V
 *               GND     -> GND
 *               (resistor pull-up 10kΩ antara Data & VCC)
 *
 *    Serial -> PA9  (TX) → USB-TTL RX
 *              PA10 (RX) → USB-TTL TX
 *              GND       → USB-TTL GND
 *
 *  Serial output:
 *    [TASK1] Timestamp:0 ms | LED:1 | Counter:1 | Core:0
 *    [TASK1] Timestamp:1000 ms | LED:0 | Counter:2 | Core:0
 *    [TASK2] Timestamp:2000 ms | Temp:28.5°C | Humidity:65.0% | Counter:1
 * ============================================================
 */

#include <Arduino.h>
#include <FreeRTOS.h>        // FreeRTOS core — disertakan otomatis oleh STM32duino
#include <task.h>            // xTaskCreate, vTaskDelay, dll.
#include <semphr.h>          // SemaphoreHandle_t, xSemaphoreCreateMutex, dll.
#include <DHT.h>

// ──────────────────────────────────────────
//  Pin & Konstanta
// ──────────────────────────────────────────
#define LED_PIN           PC13    // Onboard LED Blue Pill (active LOW)
#define DHT_PIN           PA1     // Data pin DHT22
#define DHT_TYPE          DHT22

#define TASK1_PERIOD_MS   1000    // LED toggle tiap 1 detik
#define TASK2_PERIOD_MS   2000    // Baca DHT22 tiap 2 detik

#define STACK_TASK1       256     // Stack size dalam words
#define STACK_TASK2       512

// ──────────────────────────────────────────
//  Objek & Variabel Global
// ──────────────────────────────────────────
DHT dht(DHT_PIN, DHT_TYPE);
SemaphoreHandle_t serialMutex = NULL;

// ──────────────────────────────────────────
//  Prototype Task
// ──────────────────────────────────────────
void Task1_LED(void *pvParameters);
void Task2_DHT22(void *pvParameters);

// ══════════════════════════════════════════
//  setup() — Inisialisasi & buat task
// ══════════════════════════════════════════
void setup() {
    // Gunakan Serial1 = UART1 (PA9 TX, PA10 RX) — BUKAN USB CDC
    Serial.begin(115200);
    delay(500);  // Beri waktu USB-TTL adapter siap

    pinMode(LED_PIN, OUTPUT);
    digitalWrite(LED_PIN, HIGH);  // Active LOW → LED mati saat start

    dht.begin();
    delay(2000);  // DHT22 butuh ~2 detik warm-up setelah power ON

    // Buat mutex untuk proteksi Serial
    serialMutex = xSemaphoreCreateMutex();

    Serial.println(F("============================================"));
    Serial.println(F("  STM32F103C8T6 FreeRTOS - LED + DHT22"));
    Serial.println(F("  Task1: LED Blink   Period: 1000ms"));
    Serial.println(F("  Task2: DHT22 Read  Period: 2000ms"));
    Serial.println(F("============================================"));

    // ── Task 1: LED (Prioritas 2) ─────────
    BaseType_t t1 = xTaskCreate(
        Task1_LED,
        "LED",
        STACK_TASK1,
        NULL,
        2,
        NULL
    );

    // ── Task 2: DHT22 (Prioritas 1) ───────
    BaseType_t t2 = xTaskCreate(
        Task2_DHT22,
        "DHT22",
        STACK_TASK2,
        NULL,
        1,
        NULL
    );

    if (t1 != pdPASS || t2 != pdPASS) {
        Serial.println(F("[ERROR] Gagal membuat task! Cek RAM."));
        while (1);
    }

    // Mulai FreeRTOS scheduler — fungsi ini tidak pernah return
    vTaskStartScheduler();

    // Jika sampai sini berarti scheduler gagal (RAM tidak cukup)
    Serial.println(F("[ERROR] Scheduler gagal! RAM tidak cukup."));
    while (1);
}

// ══════════════════════════════════════════
//  loop() — Tidak digunakan saat FreeRTOS aktif
// ══════════════════════════════════════════
void loop() {
    // Kosong — kontrol sepenuhnya di FreeRTOS tasks
}

// ══════════════════════════════════════════
//  TASK 1 — LED Blink
//  Toggle LED setiap TASK1_PERIOD_MS
//  Output: [TASK1] Timestamp | LED state | Counter | Core
// ══════════════════════════════════════════
void Task1_LED(void *pvParameters) {
    (void) pvParameters;

    uint8_t   ledState = 0;
    uint32_t  counter  = 0;
    TickType_t xLastWakeTime = xTaskGetTickCount();

    for (;;) {
        counter++;

        // Toggle LED state
        ledState = (ledState == 0) ? 1 : 0;

        // Active LOW: ledState=1 → nyala → LOW, ledState=0 → mati → HIGH
        digitalWrite(LED_PIN, (ledState == 1) ? LOW : HIGH);

        uint32_t ts = xTaskGetTickCount() * portTICK_PERIOD_MS;

        // Print ke Serial dengan mutex
        if (xSemaphoreTake(serialMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
            Serial.print(F("[TASK1] Timestamp:"));
            Serial.print(ts);
            Serial.print(F(" ms | LED:"));
            Serial.print(ledState);
            Serial.print(F(" | Counter:"));
            Serial.print(counter);
            Serial.println(F(" | Core:0"));
            xSemaphoreGive(serialMutex);
        }

        // Tunggu sampai periode berikutnya (presisi, tidak drift)
        vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(TASK1_PERIOD_MS));
    }
}

// ══════════════════════════════════════════
//  TASK 2 — Baca Sensor DHT22
//  Baca setiap TASK2_PERIOD_MS
//  Output: [TASK2] Timestamp | Temp | Humidity | Counter
// ══════════════════════════════════════════
void Task2_DHT22(void *pvParameters) {
    (void) pvParameters;

    uint32_t  counter = 0;
    TickType_t xLastWakeTime;

    // Delay awal 2 detik — beri waktu Task1 start duluan
    vTaskDelay(pdMS_TO_TICKS(2000));
    xLastWakeTime = xTaskGetTickCount();

    for (;;) {
        counter++;

        float temp     = dht.readTemperature();  // Celsius
        float humidity = dht.readHumidity();

        uint32_t ts = xTaskGetTickCount() * portTICK_PERIOD_MS;

        if (xSemaphoreTake(serialMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
            Serial.print(F("[TASK2] Timestamp:"));
            Serial.print(ts);
            Serial.print(F(" ms | "));

            if (isnan(temp) || isnan(humidity)) {
                Serial.print(F("Temp:ERROR | Humidity:ERROR"));
            } else {
                Serial.print(F("Temp:"));
                Serial.print(temp, 1);
                Serial.print(F("C | Humidity:"));
                Serial.print(humidity, 1);
                Serial.print(F("%"));
            }

            Serial.print(F(" | Counter:"));
            Serial.println(counter);

            xSemaphoreGive(serialMutex);
        }

        vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(TASK2_PERIOD_MS));
    }
}
