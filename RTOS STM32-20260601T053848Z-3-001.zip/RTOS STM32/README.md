# STM32F103C8T6 FreeRTOS — LED + DHT22

## Deskripsi
Program ini menjalankan **2 FreeRTOS task** secara bersamaan pada STM32F103C8T6 (Blue Pill):

| Task | Fungsi | Period |
|------|--------|--------|
| TASK1 | Toggle LED onboard | 1000 ms |
| TASK2 | Baca suhu & kelembaban DHT22 | 2000 ms |

---

## Contoh Output Serial Monitor (115200 baud)

```
============================================
  STM32F103C8T6 FreeRTOS - LED + DHT22
  Task1: LED Blink | Task2: Baca Sensor
============================================
[TASK1] Timestamp:0 ms | LED:1 | Counter:1 | Core:0
[TASK1] Timestamp:1000 ms | LED:0 | Counter:2 | Core:0
[TASK2] Timestamp:2000 ms | Temp:28.5°C | Humidity:65.0% | Counter:1
[TASK1] Timestamp:2000 ms | LED:1 | Counter:3 | Core:0
[TASK1] Timestamp:3000 ms | LED:0 | Counter:4 | Core:0
[TASK2] Timestamp:4000 ms | Temp:28.6°C | Humidity:65.2% | Counter:2
```

---

## Wiring / Skema Koneksi

```
STM32F103C8T6 Blue Pill
┌─────────────────────┐
│                     │
│  PC13 ──── LED ─── GND   (LED onboard, sudah tersedia)
│                     │
│  PA1  ──── DHT22 DATA
│  3.3V ──── DHT22 VCC
│  GND  ──── DHT22 GND
│                     │
│  PA9  ──── TX (Serial)
│  PA10 ──── RX (Serial)
│                     │
└─────────────────────┘

DHT22 Wiring Detail:
┌─────────┐
│  DHT22  │
│ 1 2 3 4 │
└─────────┘
  │ │   │
  │ │   └── GND
  │ └─── DATA → PA1 (+ pull-up 10kΩ ke 3.3V)
  └───── VCC → 3.3V
```

---

## Cara Upload

### 1. Install PlatformIO di VS Code
- Install ekstensi **PlatformIO IDE** dari VS Code Marketplace

### 2. Buka Project
```
File → Open Folder → pilih folder STM32_RTOS_DHT22
```

### 3. Koneksi ST-Link
- Hubungkan ST-Link V2 ke Blue Pill:
  - SWDIO → PA13
  - SWCLK → PA14
  - GND   → GND
  - 3.3V  → 3.3V

### 4. Build & Upload
```
Klik tombol ✓ (Build) lalu → (Upload) di status bar bawah VS Code
```

### 5. Buka Serial Monitor
```
Klik ikon 🔌 di status bar bawah VS Code
Baud rate: 115200
```

---

## Struktur Project

```
STM32_RTOS_DHT22/
├── platformio.ini      ← Konfigurasi board & library
└── src/
    └── main.cpp        ← Kode utama
```

---

## Library yang Digunakan

| Library | Versi | Fungsi |
|---------|-------|--------|
| STM32duino FreeRTOS | ^10.3.1 | RTOS scheduler |
| DHT sensor library | ^1.4.6 | Baca DHT22 |
| Adafruit Unified Sensor | ^1.1.14 | Dependency DHT lib |

---

## Penjelasan Teknis

### FreeRTOS Task
- **vTaskDelayUntil()** digunakan agar period task tetap presisi meski ada variasi waktu eksekusi
- **Mutex (serialMutex)** melindungi `Serial.print()` agar tidak tabrakan antar task
- Task1 prioritas **2** (lebih tinggi), Task2 prioritas **1**

### LED Onboard
- LED PC13 pada Blue Pill adalah **active LOW**
- `LED:1` di serial = LED menyala → `digitalWrite(PC13, LOW)`
- `LED:0` di serial = LED mati → `digitalWrite(PC13, HIGH)`

### DHT22
- Butuh warm-up ~2 detik setelah power ON → Task2 delay 2000ms di awal
- Jika pembacaan gagal → output `Temp:ERROR | Humidity:ERROR`

---

## Troubleshooting

| Masalah | Solusi |
|---------|--------|
| Upload gagal | Periksa koneksi ST-Link, pastikan BOOT0=0 |
| DHT22 selalu ERROR | Cek kabel, tambahkan resistor pull-up 10kΩ |
| Serial tidak muncul | Pastikan baud rate 115200, pilih port yang benar |
| Build error FreeRTOS | Jalankan `pio lib update` di terminal |
